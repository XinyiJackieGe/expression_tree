import org.junit.Before;
import org.junit.Test;

import expression.Expression;
import expression.ExpressionTree;

import static org.junit.Assert.*;

public class ExpressionTreeTest {
  Expression expCase1;
  Expression expCase2;
  Expression expCase3;
  Expression expCase4;
  Expression expCase5;

  @Before
  public void setup(){ }


  @Test(expected = IllegalArgumentException.class)
  public void testConstructorExcetption(){
    expCase1=new ExpressionTree("");
    expCase2=new ExpressionTree("1 5");
    expCase3=new ExpressionTree("1.5 3.2 5.3");
  }


  @Test
  public void testInfix() {
    expCase1=new ExpressionTree("1 5 *   -4 + ");
    String str1="( ( 1.0 * 5.0 ) + -4.0 )";
    assertEquals(str1,expCase1.infix());
    expCase2=new ExpressionTree("1 0 /");
    String str2="( 1.0 / 0.0 )";
    assertEquals(str2,expCase2.infix());
    expCase3=new ExpressionTree("1 2 + 5 3 - *");
    String str3="( ( 1.0 + 2.0 ) * ( 5.0 - 3.0 ) )";
    assertEquals(str3,expCase3.infix());
    expCase4=new ExpressionTree("1 2 + 5 3 - * 2 /");
    String str4="( ( ( 1.0 + 2.0 ) * ( 5.0 - 3.0 ) ) / 2.0 )";
    assertEquals(str4,expCase4.infix());
    expCase5=new ExpressionTree("2");
    String str5="2.0";
    assertEquals(str5,expCase5.infix());
  }

  @Test
  public void testSchemeExpression(){
    expCase1=new ExpressionTree("1 5 *   -4 + ");
    String str1="(+ (* 1.0 5.0) -4.0)";
    assertEquals(str1,expCase1.schemeExpression());
    expCase2=new ExpressionTree("1 0 /");
    String str2="(/ 1.0 0.0)";
    assertEquals(str2,expCase2.schemeExpression());
    expCase3=new ExpressionTree("1 2 + 5 3 - *");
    String str3="(* (+ 1.0 2.0) (- 5.0 3.0))";
    assertEquals(str3,expCase3.schemeExpression());
    expCase4=new ExpressionTree("1 2 + 5 3 - * 2 /");
    String str4="(/ (* (+ 1.0 2.0) (- 5.0 3.0)) 2.0)";
    assertEquals(str4,expCase4.schemeExpression());
    expCase5=new ExpressionTree("2");
    String str5="2.0";
    assertEquals(str5,expCase5.infix());
  }

  @Test
  public void testEvaluate(){
    expCase1=new ExpressionTree("1 5 *   -4 + ");
    assertEquals(1.0,expCase1.evaluate(),0.00001);
    expCase2=new ExpressionTree("1 0 /");
    assertEquals(Double.MAX_VALUE,expCase2.evaluate(),0.00001);
    expCase3=new ExpressionTree("1 2 + 5 3 - *");
    assertEquals(6.0,expCase3.evaluate(),0.00001);
    expCase4=new ExpressionTree("1 2 + 5 3 - * 2 /");
    assertEquals(3.0,expCase4.evaluate(),0.00001);
  }

}