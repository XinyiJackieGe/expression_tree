import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import intervals.IntervalTree;
import intervals.Intervals;

public class IntervalTreeTest {
  Intervals intervalCase1;
  Intervals intervalCase2;
  Intervals intervalCase3;
  Intervals intervalCase4;

  @Before
  public void setup(){}

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor(){
    intervalCase1=new IntervalTree("");
    intervalCase2=new IntervalTree("3,-4");
    intervalCase3=new IntervalTree("3,-4 2,5 I");
  }

  @Test
  public void testEvaluate(){
    intervalCase1=new IntervalTree("1,5");
    String str1="1,5";
    assertEquals(str1,intervalCase1.evaluate().toString());
    intervalCase2=new IntervalTree("1,5 2,8 I 4,7 U");
    String str2="2,7";
    assertEquals(str2,intervalCase2.evaluate().toString());
    intervalCase3=new IntervalTree("1,4 5,8 I");
    String str3=""+Integer.MIN_VALUE+","+Integer.MIN_VALUE;
    assertEquals(str3,intervalCase3.evaluate().toString());
  }

}