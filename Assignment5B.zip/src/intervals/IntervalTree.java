package intervals;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class IntervalTree implements Intervals {
  private IntervalNode root;

  public IntervalTree(String intervalStr) throws IllegalArgumentException{
    if (intervalStr.length() == 0) {
      throw new IllegalArgumentException("Input expression length is 0.");
    }
    List<Interval> intervalStack = new ArrayList<Interval>();
    List<IntervalNode> intervalNodeStack = new ArrayList<IntervalNode>();
    Scanner scan = new Scanner(intervalStr);
    while (scan.hasNext()) {
      String strToken = scan.next();
      if (strToken.matches("-?\\d+,-?\\d+")) {
        String strStart = strToken.substring(0, strToken.indexOf(','));
        String strEnd = strToken.substring(strToken.indexOf(',') + 1);
        int start = Integer.parseInt(strStart);
        int end = Integer.parseInt(strEnd);
        intervalStack.add(new Interval(start, end));
        intervalNodeStack.add(new IntervalLeafNode(strToken));
      } else if (strToken.matches("I|U")) {
        if (strToken.equals("I")) {
          if (intervalStack.size() < 2) {
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else {
            Interval operand2 = intervalStack.remove(intervalStack.size() - 1);
            IntervalNode rightChild = intervalNodeStack.remove(intervalNodeStack.size() - 1);
            Interval operand1 = intervalStack.remove(intervalStack.size() - 1);
            IntervalNode leftChild = intervalNodeStack.remove(intervalNodeStack.size() - 1);
            Interval newOperand = operand1.intersect(operand2);
            intervalStack.add(newOperand);
            intervalNodeStack.add(new IntervalGroupNode("I", leftChild, rightChild));
          }
        } else if (strToken.equals("U")) {
          if (intervalStack.size() < 2) {
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else {
            Interval operand2 = intervalStack.remove(intervalStack.size() - 1);
            IntervalNode rightChild = intervalNodeStack.remove(intervalNodeStack.size() - 1);
            Interval operand1 = intervalStack.remove(intervalStack.size() - 1);
            IntervalNode leftChild = intervalNodeStack.remove(intervalNodeStack.size() - 1);
            Interval newOperand = operand1.union(operand2);
            intervalStack.add(newOperand);
            intervalNodeStack.add(new IntervalGroupNode("U", leftChild, rightChild));
          }
        }
      } else {
        throw new IllegalArgumentException("Illegitimate input expression");
      }
    }
    if(intervalStack.size()==1){
      this.root=intervalNodeStack.get(0);
    } else{
      throw new IllegalArgumentException("Illegitimate input expression");
    }
  }


  @Override
  public Interval evaluate(){
    return this.root.evaluate();
  }

  @Override
  public String textTree(){
    return null;
  }
}
