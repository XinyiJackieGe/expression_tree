package intervals;

public class IntervalLeafNode implements IntervalNode {
  String token;

  public IntervalLeafNode(String token){
    this.token=token;
  }

  @Override
  public Interval evaluate(){
    String strToken=this.token;
    String strStart = strToken.substring(0, strToken.indexOf(','));
    String strEnd = strToken.substring(strToken.indexOf(',') + 1);
    int start = Integer.parseInt(strStart);
    int end = Integer.parseInt(strEnd);
    return new Interval(start, end);
  }

  @Override
  public String textTree(){
    return null;
  }
}
