package intervals;

public class IntervalGroupNode implements IntervalNode {
  private String token;
  private IntervalNode leftChild;
  private IntervalNode rightChild;

  public IntervalGroupNode(String token,IntervalNode leftChild,IntervalNode rightChild){
    this.token=token;
    this.leftChild=leftChild;
    this.rightChild=rightChild;
  }

  @Override
  public Interval evaluate(){
    Interval leftVal=this.leftChild.evaluate();
    Interval rightVal=this.rightChild.evaluate();
    if(this.token.equals("I")){
      return leftVal.intersect(rightVal);
    } else {
      return leftVal.union(rightVal);
    }
  }

  @Override
  public String textTree(){
    return null;
  }
}
