package expression;

public class ExpressionLeafNode implements ExpressionNode {
  private String token;

  public ExpressionLeafNode(String token){
    this.token=token;
  }

  @Override
  public String infix(){
    return ""+Double.parseDouble(this.token);
  }

  @Override
  public String schemeExpression(){
    return ""+Double.parseDouble(this.token);
  }

  @Override
  public double evaluate(){
    return Double.parseDouble(this.token);
  }

  @Override
  public String textTree(){
    return ""+Double.parseDouble(this.token);
  }

}
