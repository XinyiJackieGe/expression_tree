package expression;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExpressionTree implements Expression{
  private ExpressionNode root;

  public ExpressionTree(String expStr){
    if(expStr.length()==0){throw new IllegalArgumentException("Input expression length is 0.");}
    List<Double> expStack=new ArrayList<Double>();
    List<ExpressionNode> expNodeStack=new ArrayList<ExpressionNode>();
    Scanner scan=new Scanner(expStr);
    while(scan.hasNext()){
      String strToken=scan.next();
      if(strToken.matches("-?\\d+(\\.\\d+)?")) {
        expStack.add(Double.parseDouble(strToken));
        expNodeStack.add(new ExpressionLeafNode(strToken));
      } else if(strToken.matches("\\+|\\*|\\-|\\/")){
        if(strToken.equals("+")){
          if(expStack.size()<2){
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else{
            Double operand2=expStack.remove(expStack.size()-1);
            ExpressionNode rightChild=expNodeStack.remove(expNodeStack.size()-1);
            Double operand1=expStack.remove(expStack.size()-1);
            ExpressionNode leftChild=expNodeStack.remove(expNodeStack.size()-1);
            Double newOperand=operand1+operand2;
            expStack.add(newOperand);
            expNodeStack.add(new ExpressionGroupNode("+",leftChild,rightChild));
          }
        } else if(strToken.equals("*")){
          if(expStack.size()<2){
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else{
            Double operand2=expStack.remove(expStack.size()-1);
            ExpressionNode rightChild=expNodeStack.remove(expNodeStack.size()-1);
            Double operand1=expStack.remove(expStack.size()-1);
            ExpressionNode leftChild=expNodeStack.remove(expNodeStack.size()-1);
            Double newOperand=operand1*operand2;
            expStack.add(newOperand);
            expNodeStack.add(new ExpressionGroupNode("*",leftChild,rightChild));
          }
        } else if(strToken.equals("-")){
          if(expStack.size()<2){
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else{
            Double operand2=expStack.remove(expStack.size()-1);
            ExpressionNode rightChild=expNodeStack.remove(expNodeStack.size()-1);
            Double operand1=expStack.remove(expStack.size()-1);
            ExpressionNode leftChild=expNodeStack.remove(expNodeStack.size()-1);
            Double newOperand=operand1-operand2;
            expStack.add(newOperand);
            expNodeStack.add(new ExpressionGroupNode("-",leftChild,rightChild));
          }
        } else if(strToken.equals("/")) {
          if (expStack.size() < 2) {
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else {
            Double operand2 = expStack.remove(expStack.size() - 1);
            ExpressionNode rightChild = expNodeStack.remove(expNodeStack.size() - 1);
            Double operand1 = expStack.remove(expStack.size() - 1);
            ExpressionNode leftChild = expNodeStack.remove(expNodeStack.size() - 1);
            Double newOperand;
            if(operand2==0){
              newOperand=Double.MAX_VALUE;
            } else {
             newOperand=operand1 / operand2;
            }
            expStack.add(newOperand);
            expNodeStack.add(new ExpressionGroupNode("/", leftChild, rightChild));
          }
        }
      } else{
        throw new IllegalArgumentException("Illegitimate input expression");
      }
    }
    if(expStack.size()==1){
      this.root=expNodeStack.get(0);
    } else{
      throw new IllegalArgumentException("Illegitimate input expression");
    }
  }

  @Override
  public double evaluate(){
    return this.root.evaluate();
  }

  @Override
  public String infix(){
    return this.root.infix();
  }

  @Override
  public String schemeExpression(){
    return this.root.schemeExpression();
  }

  @Override
  public String textTree(){return this.root.textTree();}
}
