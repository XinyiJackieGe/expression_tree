package expression;

public interface ExpressionNode {

  String infix();

  double evaluate();

  String schemeExpression();

  String textTree();
}
