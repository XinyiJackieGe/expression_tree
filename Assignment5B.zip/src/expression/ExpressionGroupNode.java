package expression;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExpressionGroupNode implements ExpressionNode {
  String token;
  ExpressionNode leftChild;
  ExpressionNode rightChild;

  public ExpressionGroupNode(String token,ExpressionNode leftChild,ExpressionNode rightChild){
    this.token=token;
    this.leftChild=leftChild;
    this.rightChild=rightChild;
  }

  @Override
  public String infix(){
    return "( "+this.leftChild.infix()+" "+this.token+" "+this.rightChild.infix()+" )";
  }

  @Override
  public String schemeExpression(){
    return "("+this.token+" "+this.leftChild.schemeExpression()+" "+
            this.rightChild.schemeExpression()+")";
  }

  @Override
  public double evaluate(){
    double leftValue=this.leftChild.evaluate();
    double rightValue=this.rightChild.evaluate();
    if(this.token.equals("+")){
      return leftValue+rightValue;
    } else if(this.token.equals("*")){
      return leftValue*rightValue;
    } else if(this.token.equals("-")){
      return leftValue-rightValue;
    } else {
      if(rightValue==0){
        return Double.MAX_VALUE;
      } else {
        return leftValue/rightValue;
      }
    }
  }

  @Override
  public String textTree(){
    String leftStr=this.leftChild.textTree();
    String rightStr=this.rightChild.textTree();
    return "   "+this.token+"\n   |\n   |\n   |___"+leftStr+"\n   |\n   |___"+rightStr;
  }

}
