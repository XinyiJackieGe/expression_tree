package intervals;

public abstract class AbsIntervalNode implements IntervalNode {
  protected String token;

  public AbsIntervalNode(String token){
    this.token=token;
  }
}
