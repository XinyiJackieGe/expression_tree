package intervals;



public class IntervalTree implements Intervals{
  IntervalNode root;

  public IntervalTree(String strInterval){

    String[] words=strInterval.split("\\s+");
    if(words.length==0){
      throw new IllegalArgumentException("Input invalid");
    } else if (words.length==1){
      if(words[0].matches("-?\\d+,-?\\d+")){
        root=new IntervalLeafNode(words[0]);
      } else {
        throw new IllegalArgumentException("Input Invalid");
      }
    } else if(words.length==2){
      throw new IllegalArgumentException("Invalid Input");
    } else {
      root = new IntervalGroupNode(strInterval);
    }

  }

  @Override
  public Interval evaluate(){
    return this.root.evaluate();
  }
}
