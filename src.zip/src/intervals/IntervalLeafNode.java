package intervals;

public class IntervalLeafNode extends AbsIntervalNode{
  public IntervalLeafNode(String token){
    super(token);
  }

  @Override
  public Interval evaluate() {
    String strToken=this.token;
    String strStart = strToken.substring(0, strToken.indexOf(','));
    String strEnd = strToken.substring(strToken.indexOf(',') + 1);
    int start = Integer.parseInt(strStart);
    int end = Integer.parseInt(strEnd);
    return new Interval(start, end);
  }
}
