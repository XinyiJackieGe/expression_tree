package intervals;

public interface IntervalNode {
  Interval evaluate();
}
