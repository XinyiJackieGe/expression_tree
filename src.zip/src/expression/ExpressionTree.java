package expression;

import java.util.Scanner;

public class ExpressionTree implements Expression {
  ExpressionNode root;

  public ExpressionTree(String expStr) throws IllegalArgumentException{
    String[] words=expStr.split("\\s+");
    if(words.length==0){
      throw new IllegalArgumentException("Input invalid");
    } else if (words.length==1){
      if(words[0].matches("-?\\d+(\\.\\d+)?")){
      root=new ExpressionLeafNode(words[0]);
      } else {
      throw new IllegalArgumentException("Input Invalid");
      }
    } else if(words.length==2){
      throw new IllegalArgumentException("Invalid Input");
    } else {
      root = new ExpressionGroupNode(expStr);
    }
  }

  @Override
  public double evaluate(){
    return this.root.evaluate();
  }

  @Override
  public String infix(){
    return this.root.infix();
  }

  @Override
  public String schemeExpression(){
    return this.root.schemeExpression();
  }
}
