package expression;

public class ExpressionLeafNode extends AbsExpressionNode {
  public ExpressionLeafNode(String token){
    super(token);
  }

  @Override
  public String infix(){
    return ""+Double.parseDouble(this.token);
  }

  @Override
  public String schemeExpression(){
    return ""+Double.parseDouble(this.token);
  }

  @Override
  public double evaluate(){
    return Double.parseDouble(this.token);
  }

}
