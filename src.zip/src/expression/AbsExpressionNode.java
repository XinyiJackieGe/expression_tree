package expression;

abstract public class AbsExpressionNode implements ExpressionNode{
  protected String token;

  public AbsExpressionNode(String token){
    this.token=token;
  }
}
