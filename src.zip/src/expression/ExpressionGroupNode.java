package expression;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExpressionGroupNode extends AbsExpressionNode {
  ExpressionNode leftChild;
  ExpressionNode rightChild;

  private ExpressionGroupNode(String token,ExpressionNode leftChild,ExpressionNode rightChild){
    super(token);
    this.leftChild=leftChild;
    this.rightChild=rightChild;
  }

  public ExpressionGroupNode(String expStr) throws IllegalArgumentException{
    super(null);
    if(expStr.length()==0){throw new IllegalArgumentException("Input expression length is 0.");}
    List<Double> expStack=new ArrayList<Double>();
    List<ExpressionNode> expNodeStack=new ArrayList<ExpressionNode>();
    Scanner scan=new Scanner(expStr);
    while(scan.hasNext()){
      String strToken=scan.next();
      if(strToken.matches("-?\\d+(\\.\\d+)?")) {
        expStack.add(Double.parseDouble(strToken));
        expNodeStack.add(new ExpressionLeafNode(strToken));
      } else if(strToken.matches("\\+|\\*")){
        if(strToken.equals("+")){
          if(expStack.size()<2){
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else{
            Double operand2=expStack.remove(expStack.size()-1);
            ExpressionNode rightChild=expNodeStack.remove(expNodeStack.size()-1);
            Double operand1=expStack.remove(expStack.size()-1);
            ExpressionNode leftChild=expNodeStack.remove(expNodeStack.size()-1);
            Double newOperand=operand1+operand2;
            expStack.add(newOperand);
            this.leftChild=leftChild;
            this.rightChild=rightChild;
            this.token="+";
            expNodeStack.add(new ExpressionGroupNode("+",leftChild,rightChild));
          }
        } else if(strToken.equals("*")){
          if(expStack.size()<2){
            throw new IllegalArgumentException("Illegitimate input expression.");
          } else{
            Double operand2=expStack.remove(expStack.size()-1);
            ExpressionNode rightChild=expNodeStack.remove(expNodeStack.size()-1);
            Double operand1=expStack.remove(expStack.size()-1);
            ExpressionNode leftChild=expNodeStack.remove(expNodeStack.size()-1);
            Double newOperand=operand1+operand2;
            expStack.add(newOperand);
            this.leftChild=leftChild;
            this.rightChild=rightChild;
            this.token="*";
            expNodeStack.add(new ExpressionGroupNode("*",leftChild,rightChild));
          }
        }
      } else{
        throw new IllegalArgumentException("Illegitimate input expression");
      }
    }

  }

  @Override
  public String infix(){
    return "( "+this.leftChild.infix()+" "+this.token+" "+this.rightChild.infix()+" )";
  }

  @Override
  public String schemeExpression(){
    return "("+this.token+" "+this.leftChild.schemeExpression()+" "+
            this.rightChild.schemeExpression()+")";
  }

  @Override
  public double evaluate(){
    double leftValue=this.leftChild.evaluate();
    double rightValue=this.rightChild.evaluate();
    if(this.token.equals("+")){
      return leftValue+rightValue;
    } else{
      return leftValue*rightValue;
    }
  }

}
